[org 0x100]

start:
    jmp setup

old_vec dd 0
notice  db ' [S] Key Pressed! ', 0

new_09:
    pusha
    push ds
    push es

    in al, 0x60   ;خواندن اسکن کد مربوط به کلید کیبورد
    cmp al, 0x1F       
    jne .exit

    mov ax, 0xB800  ;ادرس vram
    mov es, ax
    xor di, di         
    
    push cs
    pop ds
    mov si, notice

.loop:
    lodsb
    test al, al
    jz .exit
    mov ah, 0x1E      
    stosw               
    jmp .loop

.exit:
    pop es
    pop ds
    popa
    jmp far [cs:old_vec]   ;بازگشت به کد اصلی BIOS

setup:
    mov ax, 0x3509
    int 0x21
    mov [old_vec], bx   ; ذخیره افست قدیمی
    mov [old_vec+2], es   ; ذخیره سگمنت قدیمی

    ; جایگذاری ادرس تابع خودمان
    mov ax, 0x2509
    mov dx, new_09
    int 0x21

    mov dx, inst_msg
    mov ah, 0x09
    int 0x21

    mov dx, (setup - start + 0x100)
    shr dx, 4
    inc dx
    mov ax, 0x3100
    int 0x21

inst_msg db 'Resident driver active.$'